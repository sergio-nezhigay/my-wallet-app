export const STATUS = {
  INIT: "init",
  ERROR: "error",
  INFO: "info",
};
