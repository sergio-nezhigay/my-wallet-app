import MoneyTransferForm from "./MoneyTransferForm";

export default MoneyTransferForm;
